"""
A Archery CLI tool for targeted tests from the command line.
.. moduleauthor:: Anand Tiwari
"""

__version__ = '0.4.0'
